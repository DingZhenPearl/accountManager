<template>
	<view class="shurukuang">
		<view class="jine">
			<input class="jinein" type='number'>
			金额
		</view>
		<view class="leibie">
			<input class="leibiein">类别
		</view>
	</view>
		

	
</template>

<script>
	export default {
		data() {
			return {
				title: 'Hello'
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>

